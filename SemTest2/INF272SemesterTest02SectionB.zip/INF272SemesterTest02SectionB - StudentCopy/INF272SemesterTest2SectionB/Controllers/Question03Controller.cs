﻿using INF272SemesterTest2SectionB.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace INF272SemesterTest2SectionB.Controllers
    {
    public class Question03Controller : Controller
        {
        [HttpGet]
        public ActionResult Question03()
            {
            return View();
            }

        [HttpPost]
        public ActionResult Question03(int min)
            {

            // Complete this section of the controller (5 marks).
            // -------------------------------------------------
            // -------------------------------------------------



            return View();

            // -------------------------------------------------
            // -------------------------------------------------
            // Complete this section of the controller.
            }
        }
    }