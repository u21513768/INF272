﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INF272SemesterTest2SectionC.Models
{
    public class Artist
    {
        //TODO: Complete this.
        //Hint: Index view might assist you with choosing the names for the prooperties.
    }
}
