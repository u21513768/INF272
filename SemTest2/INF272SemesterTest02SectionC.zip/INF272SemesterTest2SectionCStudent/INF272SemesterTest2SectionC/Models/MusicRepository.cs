﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace INF272SemesterTest2SectionC.Models
{
    public class MusicRepository
    {
        public static String sqlDBConnectionString = ""; //DOn't forget to modify the string

        public static List<Artist> GetArtists() {
            List<Artist> artists = new List<Artist>();

            //TODO: read artists

            return artists;
        }

        public static List<Album> GetAlbumsOfArtist(int artistID) {
            List<Album> albums = GetAlbums().Where(album => album.ArtistID == artistID).ToList();
            return albums;
        }

        public static void DeleteAlbum(int AlbumID) {
            //TODO: remove album
        }

        public static void DeleteArtist(int ArtistID)
        {
            //TODO: remove artist
        }

        public static List<Album> GetAlbums() {
            List<Album> albums = new List<Album>();

            //TODO: read albums

            return albums;
        }
    }
}
