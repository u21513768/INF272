﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WinterBoxes.Models
{
    public class Box
    {
        public String BoxName { get; set; }
        public String[] Items { get; set; }
    }
}
