window.addEventListener("load", function () {




    

});

var count = 0;

//create the function to play the game with feedback
function play() {



};

//create the function to reset the colours of the dartboard
function reset() {
    
   

}

