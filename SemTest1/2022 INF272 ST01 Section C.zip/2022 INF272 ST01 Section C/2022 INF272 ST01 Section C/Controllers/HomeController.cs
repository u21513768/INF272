﻿using System.Web.Mvc;

namespace _2022_INF272_ST01_Section_C.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Question01()
        {
            return View();
        }

        public ActionResult Question02()
        {
            return View();
        }
    }
}