﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace INF272DB1StudentFiles2022.Models
{
    public class DestinationModel
    {
        //create data properties and constructors
    }
}