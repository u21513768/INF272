﻿namespace ProductSupplier.Models
    {

    // Complete this Model. Consider the data that it would receive and manage.
    // You would also need to use this model to manage the data associated with
    // the supplier (SupplierID), and the Name of the supplier.

    public class Supplier  // Complete this model......
    {
        //new Supplier{ SupplierID = 1, Name = "Develop Manufacturing Ltd" }
        public int SupplierID { get; set; }
        public string Name { get; set; }
    }
}