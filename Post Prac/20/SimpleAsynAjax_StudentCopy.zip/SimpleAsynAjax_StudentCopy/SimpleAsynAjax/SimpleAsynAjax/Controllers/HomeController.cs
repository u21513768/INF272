﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SimpleAsynAjax.Models;
using Newtonsoft.Json;
using System.Net;
using System.Data;
using System.Threading;


namespace SimpleAsynAjax.Controllers
    {

    public class HomeController : Controller
        {

        public ExampleDatabaseEntities db = new ExampleDatabaseEntities();
        public ActionResult Index()
            {
            return View();
            }

        [HttpPost]
        public ActionResult Create()
            {
            //----------- Edit Here -----------

            return RedirectToAction("Index");
            }

        public JsonResult GetExampleTable()
            {
            //----------- Edit Here -----------

            return Json(JsonRequestBehavior.AllowGet); // <<<<<<<<< You will need to change this to a Json return.
            }
        }
    }


