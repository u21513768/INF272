﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

namespace RandomCourseFBook.Models
{
    public class Image
    {
        public int StudentID { get; set; }
        public String ImageRaw { get; set; }
    }
}