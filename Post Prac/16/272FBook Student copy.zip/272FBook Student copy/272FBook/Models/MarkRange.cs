﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RandomCourseFBook.Models
{
    public class MarkRange
    {
        public String Symbol { get; set; }
        public int MinOfRange { get; set; }
        public int MaxOfRange { get; set; }
    }
}