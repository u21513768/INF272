﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace EFLinqLambda.Models
{
    public class Product
    {
        [Key]
        public int ProductID { get; set; }

        [Display(Name = "Product Name")]
        public string ProductName { get; set; }

        [Display(Name = "Product Quantity")]
        [Range(0, int.MaxValue, ErrorMessage = "Please enter valid integer Number")]
        public int ProductQuantity { get; set; }

        [Display(Name = "Product Price")]
        [DataType(DataType.Currency)]
        public decimal ProductPrice { get; set; }

        [Display(Name = "Date Added")]
        [DataType(DataType.Date)]
        public DateTime ProductEntryDate { get; set; }

    }
}