﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EFLinqLambda.Models;
using System.Data.Entity; // Add this

namespace EFLinqLambda.Controllers
{
    public class SimpleLINQController : Controller
    {
        LibraryEntities db = new LibraryEntities();
        public ActionResult TakeValue()
        {
            var result = db.students.Take(5);

            return View(result);
        }

        public ActionResult WhereClause()
        {
            var result = from s in db.students
                          where s.surname == "Wood"
                          select s;
            return View(result);
        }
        public ActionResult ExtendedWhereClause()
        {
            var result = from s in db.students
                         where s.surname == "Wood" && s.gender == "F"
                         select s;

            //var result = db.students.Where(s => s.surname == "Wood" && s.gender == "F");

            return View(result);
        }
        public ActionResult MultiWhereClause()
        {
            var result = from s in db.students
                         where s.surname == "Wood" && s.gender == "F"
                         where s.point > 100
                         select s;

            //var result = db.students.Where(s => s.surname == "Wood").Where(s => s.gender == "F");
            
            return View(result);
        }
        public ActionResult OrderBy()
        {
            var result = from s in db.students
                         orderby s.name descending
                         select s;

            //var result = db.students.OrderBy(s => s.name);

            return View(result);

        }
        public ActionResult OrderByThenBy()
        {
            //var result = db.students.OrderBy(s => s.name).ThenByDescending(s => s.surname);
            //var result = db.students.OrderBy(s => s.name).ThenBy(s => s.birthdate);

            var result = db.students.OrderBy(s => s.name).ThenByDescending(s => s.birthdate);

            return View(result);
        }

        public ActionResult LambdaDateExample()
        {
   
            var result = db.students.Where(s => s.birthdate >= new DateTime(2001, 8, 27));

            return View(result);
        }

        public ActionResult LambdaPointSum()
        {

            var result = db.students.Sum(s => s.point);

            return View(result);
        }

        public ActionResult LambdaOrderByThenByExample()
        {

            var result = db.students.OrderBy(s => s.birthdate).ThenByDescending(s => s.surname == "Wood").Where(s => s.gender == "F").Where(s => s.birthdate >= new DateTime(2001, 8, 27)).Take(3);

            return View(result);
        }

    }
}