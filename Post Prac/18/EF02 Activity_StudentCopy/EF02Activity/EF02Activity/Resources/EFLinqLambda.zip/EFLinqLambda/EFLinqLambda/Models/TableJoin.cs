﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EFLinqLambda.Models
{
    public class TableJoin
    {
        public student StudentDetails { get; set; }
        public borrow BorrowDetails { get; set; }
    }
}