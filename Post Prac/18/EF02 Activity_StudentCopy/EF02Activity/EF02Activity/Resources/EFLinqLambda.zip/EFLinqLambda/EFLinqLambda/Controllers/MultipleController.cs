﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EFLinqLambda.Models;
using PagedList;
using System.Data.Entity; // Add this

namespace EFLinqLambda.Controllers
{
    public class MultipleController : Controller
    {

        LibraryEntities db = new LibraryEntities();

        public ActionResult TableJoinQuerySyntax() // Uses anonemous source (Class) in model.
        {
            //Using QuerySyntax
            List<student> students = db.students.ToList();
            List<borrow> borrows = db.borrows.ToList();

            var querySyntax = (from sd in students
                               join bd in borrows
                               on sd.studentId equals bd.studentId
                               select new TableJoin
                               {
                                   StudentDetails = sd,
                                   BorrowDetails = bd
                               });

            return View(querySyntax);
        }

        // GET: Multiple (more than two using simple LINQ)
        public ActionResult MultipleTableJoin()
        {

            List<book> books = db.books.ToList();
            List<author> authors = db.authors.ToList();
            List<type> types = db.types.ToList();

            // Version 1 with Temporary Tables
            //-------------------------------------------------------------------
            var multipletables = from a in authors
                                 join b in books on a.authorId equals b.authorId into tempTable01
                                 from b in tempTable01.ToList()
                                 join t in types on b.typeId equals t.typeId into tempTable02
                                 from t in tempTable02.ToList()
                                 select new MultipleClass
                                 {
                                     AuthorDetails = a,
                                     BookDetails = b,
                                     TypeDetails = t
                                 };

            return View(multipletables);

            // Version 2 without Temporary Tables
            //-------------------------------------------------------------------
            //var multipletables = from a in authors
            //                     join b in books on a.authorId equals b.authorId
            //                     join t in types on b.typeId equals t.typeId
            //                     select new MultipleClass
            //                     {
            //                         AuthorDetails = a,
            //                         BookDetails = b,
            //                         TypeDetails = t
            //                     };

            //return View(multipletables);

        }
    }
}
