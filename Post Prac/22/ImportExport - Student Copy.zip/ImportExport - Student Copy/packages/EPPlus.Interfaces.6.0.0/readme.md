﻿# EPPlus.Interfaces
Interfaces used by EPPlus for drawing operations like imaging and text measuring.