﻿using ImportExportPractical.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.Entity;
using OfficeOpenXml;
using System.IO;

namespace ImportExportPractical.Controllers
{
    public class OrderController : Controller
    {
        private readonly ProductOrderEntities db = new ProductOrderEntities();
        // GET: Order
        public ActionResult Index()
        {
            /* Edit Here */

            return View();
        }

        public void ExportCustomers()
        {
            /* Edit Here */

        }
    }
}