﻿using System;
using System.Collections.Generic;
using DB2ClassExercise.Models;
using System.Data.SqlClient;

namespace DB2ClassExercise.Data
{
    public class SomeDataService
    {

        private static SomeDataService instance;
        public String connectionString;

        public static SomeDataService getInstance() {
            if (instance == null) {
                instance = new SomeDataService();
            }
            return instance;
        }

        public void setConnectionString(String someConnStr) {
            connectionString = someConnStr;
        }

        public List<Course> getAvailableCourses() {
            List<Course> data = new List<Course>();
            //TODO: Complete this
            return data;
        }

        //TODO: Uncommment and complete this
        /*
        public List<???> getAssignmentsOfCourse(int courseID) {
            List<???> assignments = new List<???>();

            return assignments;
        }
        */

    }
}
