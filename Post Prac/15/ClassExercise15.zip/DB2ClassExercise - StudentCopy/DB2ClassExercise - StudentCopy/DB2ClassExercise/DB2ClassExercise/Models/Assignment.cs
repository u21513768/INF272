﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DB2ClassExercise.Models
{
    public class Assignment
    {
        //TODO: Complete this
        public int ID { get; set; }
        public string CourseName { get; set; }
        public string CourseDescription { get; set; }
        public string StudentName { get; set; }
        public string StaffName { get; set; }
       
    }
}
